# -*- coding: utf-8 -*-
import aiohttp
import asyncio

print("by tblyakee")
print("https://discord.gg/RmzdxdU5e3")
async def send_message(webhook_url, message_text, message_count):
    async with aiohttp.ClientSession() as session:
        for _ in range(message_count):
            async with session.post(webhook_url, json={"content": message_text}) as response:
                if response.status != 200:
                    print(f"Send Message: {response.status}")

async def main():
    # Ask for the Discord webhook
    webhook_url = input("Please enter your Discord webhook: ")

    # Ask for the message text
    message_text = input("What do you want to write? ")

    # Ask for the number of messages to send
    message_count = int(input("How many times do you want to send the message? "))

    # Send the messages
    await send_message(webhook_url, message_text, message_count)

    print(f"{message_count} messages were sent successfully.")

if __name__ == "__main__":
    asyncio.run(main())
